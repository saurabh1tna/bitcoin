# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bitcoin']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'bitcoin',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Saurabh Kumar',
    'author_email': 'saurabh1tna@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
