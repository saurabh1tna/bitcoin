import os

print(os.path.dirname(os.getcwd()))